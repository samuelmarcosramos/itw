var vm = function () {
    console.log('ViewModel initiated...');
    var self = this;

    self.baseUri = ko.observable('http://192.168.160.58/Paris2024/API/Athletics/Events');
    self.displayName = 'Paris2024 Modalities List';
    self.error = ko.observable('');
    self.Stages = ko.observableArray([]);
    self.favourites = ko.observableArray([]);
    
    // Dropdown filter observables
    self.availableEvents = ko.observableArray([]);
    self.availableStages = ko.observableArray([]);
    self.selectedEvent = ko.observable(null);
    self.selectedStage = ko.observable(null);

    // Computed filtered stages
    self.filteredStages = ko.computed(function () {
        let filtered = self.Stages();
        if (self.selectedEvent()) {
            filtered = filtered.filter(stage => stage.EventId === self.selectedEvent());
        }
        if (self.selectedStage()) {
            filtered = filtered.filter(stage => stage.StageId === self.selectedStage());
        }
        return filtered;
    });

    self.loadSports = function () {
        console.log('Chamando API para carregar todos os eventos...');
        ajaxHelper(self.baseUri(), 'GET').done(function (data) {
            console.log('Dados recebidos:', data);

            const mappedStages = [];
            const events = new Set();
            const stages = new Set();

            data.forEach(event => {
                events.add({ id: event.EventId, name: event.EventName });
                event.Stages.forEach(stage => {
                    stages.add({ id: stage.StageId, name: stage.StageName });
                    mappedStages.push({
                        EventId: event.EventId,
                        EventName: event.EventName,
                        StageId: stage.StageId,
                        StageName: stage.StageName,
                    });
                });
            });

            self.Stages(mappedStages);
            self.availableEvents(Array.from(events).map(e => e.id));
            self.availableStages(Array.from(stages).map(s => s.id));
        });
    };

    function ajaxHelper(uri, method, data) {
        self.error('');
        return $.ajax({
            type: method,
            url: uri,
            dataType: 'json',
            contentType: 'application/json',
            data: data ? JSON.stringify(data) : null,
            error: function (jqXHR, textStatus, errorThrown) {
                console.error(`AJAX Call[${uri}] Falhou...`);
                self.error(errorThrown);
            }
        });
    }

    self.loadFavorites = function () {
        let storedFavs = localStorage.getItem('favorites_s');
        if (storedFavs) {
            self.favourites(JSON.parse(storedFavs));
        }
    };

    self.saveFavorites = function () {
        localStorage.setItem('favorites_s', JSON.stringify(self.favourites()));
    };

    self.toggleFavorite = function (stage) {
        if (self.favourites.indexOf(stage.StageId) === -1) {
            self.favourites.push(stage.StageId);
            alert(`${stage.StageName} foi adicionado aos favoritos!`);
        } else {
            self.favourites.remove(stage.StageId);
            alert(`${stage.StageName} foi removido dos favoritos!`);
        }
        self.saveFavorites();
    };

    self.loadFavorites();
    self.loadSports();
};

$(document).ready(function () {
    console.log('Aplicando bindings...');
    ko.applyBindings(new vm());
});
