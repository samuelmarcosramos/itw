var vm = function () {
    console.log('ViewModel initiated...');
    var self = this;

    self.baseUri = ko.observable('http://192.168.160.58/Paris2024/API/Cycling_Tracks/Events');
    self.error = ko.observable('');
    self.Stages = ko.observableArray([]);
    self.availableEvents = ko.observableArray([]);
    self.availableStages = ko.observableArray([]);
    self.selectedEvent = ko.observable();
    self.selectedStage = ko.observable();
    self.favourites = ko.observableArray([]);

    function ajaxHelper(uri, method, data) {
        self.error('');
        return $.ajax({
            type: method,
            url: uri,
            dataType: 'json',
            contentType: 'application/json',
            data: data ? JSON.stringify(data) : null,
            error: function (jqXHR, textStatus, errorThrown) {
                console.error(`AJAX Call[${uri}] Failed: ${textStatus}`);
                self.error(errorThrown);
            }
        });
    }

    self.loadSports = function () {
        console.log('Fetching data...');
        ajaxHelper(self.baseUri(), 'GET').done(function (data) {
            console.log('Data received:', data);

            const mappedStages = data.flatMap(event => event.Stages.map(stage => ({
                EventId: event.EventId,
                EventName: event.EventName,
                StageId: stage.StageId,
                StageName: stage.StageName
            })));

            self.Stages(mappedStages);
            self.availableEvents([...new Set(mappedStages.map(s => s.EventName))]);
            self.availableStages([...new Set(mappedStages.map(s => s.StageName))]);
        });
    };

    self.filteredStages = ko.computed(() => {
        return self.Stages().filter(stage => {
            const matchesEvent = self.selectedEvent() ? stage.EventName === self.selectedEvent() : true;
            const matchesStage = self.selectedStage() ? stage.StageName === self.selectedStage() : true;
            return matchesEvent && matchesStage;
        });
    });

    self.loadFavorites = function () {
        const storedFavs = localStorage.getItem('favorites_s');
        if (storedFavs) {
            self.favourites(JSON.parse(storedFavs));
        }
    };

    self.saveFavorites = function () {
        localStorage.setItem('favorites_s', JSON.stringify(self.favourites()));
    };

    self.toggleFavorite = function (stage) {
        const exists = self.favourites.indexOf(stage.StageId);
        if (exists === -1) {
            self.favourites.push(stage.StageId);
            alert(`${stage.StageName} added to favorites!`);
        } else {
            self.favourites.remove(stage.StageId);
            alert(`${stage.StageName} removed from favorites!`);
        }
        self.saveFavorites();
    };

    self.loadFavorites();
    self.loadSports();
};

$(document).ready(function () {
    console.log('Applying bindings...');
    ko.applyBindings(new vm());
});
